<?php
$emailku = 'onlyduo911@gmail.com'; // GANTI EMAIL KAMU DISINI
?>